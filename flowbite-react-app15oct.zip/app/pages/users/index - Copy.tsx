//pages/users/index.js

import React from "react";

const Users = () => {
    return <h1>Users Page</h1>;
};

export default Users;